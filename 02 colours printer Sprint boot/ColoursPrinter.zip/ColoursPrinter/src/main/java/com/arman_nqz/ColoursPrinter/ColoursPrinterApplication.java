package com.arman_nqz.ColoursPrinter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColoursPrinterApplication {

	public static void main(String[] args) {
		SpringApplication.run(ColoursPrinterApplication.class, args);
	}

}
