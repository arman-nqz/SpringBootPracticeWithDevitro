package com.armatech.jdbcTemplateTrain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcTemplateTrainApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcTemplateTrainApplication.class, args);
	}

}
