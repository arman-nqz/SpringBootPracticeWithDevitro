package com.arman_nqz.starter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
